﻿using System;

namespace $safeprojectname$.Model
{
    public class Country
    {
        public Guid CountryId { get; set; }
        public string Name { get; set; }
    }
}