﻿using System;

namespace $safeprojectname$.Model
{
    public class State
    {
        public string Name { get; set; }
        public Guid StateId { get; set; }
    }
}